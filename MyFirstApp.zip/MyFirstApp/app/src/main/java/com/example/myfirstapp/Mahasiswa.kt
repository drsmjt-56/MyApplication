package com.example.myfirstapp

class Mahasiswa(val nama: String, val nim: String) {
}