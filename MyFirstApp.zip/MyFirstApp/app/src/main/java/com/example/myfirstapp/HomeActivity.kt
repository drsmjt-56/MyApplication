package com.example.myfirstapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val dataList = ArrayList<Mahasiswa>()
        dataList.add(Mahasiswa("Budi", "24.12.0000"))
        dataList.add(Mahasiswa("Siti", "24.12.1111"))
        dataList.add(Mahasiswa("Andi", "24.12.2222"))
        dataList.add(Mahasiswa("Rina", "24.12.3333"))

        val rvMahasiswa: RecyclerView = findViewById(R.id.rv_mahasiswa)
        rvMahasiswa.layoutManager = LinearLayoutManager(this)
        val adapter = MahasiswaAdapter(dataList)
        rvMahasiswa.adapter = adapter

//        if (savedInstanceState == null) {
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.fragment_container, DashboardFragment())
//                .commit()
//        }

        // Di dalam onCreate
//        val tvWelcomeMessage: TextView = findViewById(R.id.tv_welcome_message)


        // Mengambil data username dari Intent
//        val username = intent.getStringExtra("EXTRA_USERNAME")


        // Menampilkan data ke TextView
//        tvWelcomeMessage.text = "Selamat Datang, $username!"

        // Buka Situs Web https://amikom.ac.id
        val btnOpenWebsite: Button = findViewById(R.id.btn_open_website)
        btnOpenWebsite.setOnClickListener {
            // 1. Membuat Intent untuk pindah ke Situs Web https://amikom.ac.id
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = android.net.Uri.parse("https://amikom.ac.id")


            // 2. Menjalankan Intent
            startActivity(intent)
        }

    }
}