package com.example.myfirstapp

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MahasiswaAdapter(private val datalist: List<Mahasiswa>)
    : RecyclerView.Adapter<MahasiswaAdapter.ViewHolder>() {
    @SuppressLint("ResourceType")
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.id.item_row_mahasiswa, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val mahasiswa = datalist[position]
        holder.tvNama.text = mahasiswa.nama
        holder.tvNim.text = mahasiswa.nim
    }

    override fun getItemCount(): Int {
        return datalist.size
    }

    class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNama: TextView = itemView.findViewById(R.id.tv_nama_mahasiswa)
        val tvNim : TextView = itemView.findViewById(R.id.tv_nim_mahasiswa)
    }
}